# Virtual_Racing
A repo that uses the donkey car simulator in order to train/test and compete in virtual races !

A video of my model running on the simulator is available at: https://youtu.be/SXbYq9_sV_U

# documentation for the donkey Car Simulator
https://docs.donkeycar.com/guide/virtual_race_league/

# download latest versions of the simulator
https://github.com/tawnkramer/gym-donkeycar/releases/

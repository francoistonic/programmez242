export class CountryModel {
    public id: number;
    public name: string;
    public description: string;
}